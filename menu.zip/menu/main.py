import pygame
import button



pygame.init()
screen = pygame.display.set_mode((910, 910))
pygame.display.set_caption('Start Menu')

background = pygame.image.load('mono2.png')

start = pygame.image.load('start3.png')
p1 = pygame.image.load('n1.png')
p2 = pygame.image.load('n2.png')
p3 = pygame.image.load('n3.png')
p4 = pygame.image.load('n4.png')

easy = pygame.image.load('easy1.png')
hard = pygame.image.load('hard1.png')

exit_img = pygame.image.load('quit3.png')

continue_img = pygame.image.load('cont1.png')



start_button = button.Button(320, 300, start, 0.2)
exit_button = button.Button(320, 500, exit_img, 0.2)
def mainMenu():
    run = True
    while run:
        screen.blit(background, (0, 0))

        if start_button.draw(screen):
            players()

        if exit_button.draw(screen):
            pygame.quit()

        for event in pygame.event.get():
            if event.type ==pygame.QUIT:
                run= False

        pygame.display.update()

    pygame.quit()





def players():
    p1_button = button.Button(360, 200, p1, 0.8)
    p2_button = button.Button(360, 300, p2, 0.8)
    p3_button = button.Button(360, 400, p3, 0.8)
    p4_button = button.Button(360, 500, p4, 0.8)

    font = pygame.font.Font(None, 70)
    text = font.render("Select Player Count: ", True, (0, 0, 0))
    run = True
    player = 0
    while run:
        screen.blit(background, (0, 0))
        screen.blit(text, (250, 100))
        if p1_button.draw(screen):
            difficulty()
            player = 1
        if p2_button.draw(screen):
            difficulty()
            player = 2
        if p3_button.draw(screen):
            difficulty()
            player = 3
        if p4_button.draw(screen):
            difficulty()
            player = 4


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
        pygame.display.update()

def difficulty():
    easy_button = button.Button(300, 300, easy, 0.3)
    hard_button = button.Button(300, 500, hard, 0.3)
    cont_button = button.Button(300, 600, continue_img, 0.6)

    font = pygame.font.Font(None, 70)

    text = font.render("Select Difficulty: ", True, (0, 0, 0))
    diff = "Easy"



    run = True
    while run:
        screen.blit(background, (0, 0))
        screen.blit(text, (300, 100))
        if easy_button.draw(screen):
            diff = "Easy"
        if hard_button.draw(screen):
            diff = "Hard"
        if cont_button.draw(screen):
            game()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
        pygame.display.update()

def game():
        #here is where game will go etc
    font = pygame.font.Font(None, 70)
    text = font.render("Game!", True, (0, 0, 0))
    run = True
    while run:
        screen.blit(background, (0, 0))
        screen.blit(text, (300, 200))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
        pygame.display.update()

mainMenu()